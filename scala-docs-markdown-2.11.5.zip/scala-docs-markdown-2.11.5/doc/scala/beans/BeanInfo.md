
#                             scala.beans.BeanInfo                             #

```
class BeanInfo extends Annotation
```

This annotation indicates that a JavaBean-compliant `BeanInfo` class should be
generated for this annotated Scala class.

* A `val` becomes a read-only property.
* A `var` becomes a read-write property.
* A `def` becomes a method.

* Source
  * [BeanInfo.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/beans/BeanInfo.scala#L1)


--------------------------------------------------------------------------------
                Instance Constructors From scala.beans.BeanInfo
--------------------------------------------------------------------------------


### `new BeanInfo()`                                                         ###
(defined at scala.beans.BeanInfo)
