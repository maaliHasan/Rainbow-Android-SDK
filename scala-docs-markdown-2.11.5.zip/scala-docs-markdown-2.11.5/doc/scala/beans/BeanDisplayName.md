
#                         scala.beans.BeanDisplayName                         #

```
class BeanDisplayName extends Annotation
```

Provides a display name when generating bean information. This annotation can be
attached to the bean itself, or to any member.

* Source
  * [BeanDisplayName.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/beans/BeanDisplayName.scala#L1)


--------------------------------------------------------------------------------
             Instance Constructors From scala.beans.BeanDisplayName
--------------------------------------------------------------------------------


### `new BeanDisplayName(name: String)`                                      ###

(defined at scala.beans.BeanDisplayName)


--------------------------------------------------------------------------------
                 Value Members From scala.beans.BeanDisplayName
--------------------------------------------------------------------------------


### `val name: String`                                                       ###
(defined at scala.beans.BeanDisplayName)
