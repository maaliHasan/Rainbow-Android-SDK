
#                               scala.Cloneable                               #

```
trait Cloneable extends java.lang.Cloneable
```

Classes extending this trait are cloneable across platforms (Java,.NET).

* Source
  * [Cloneable.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/Cloneable.scala#L1)

