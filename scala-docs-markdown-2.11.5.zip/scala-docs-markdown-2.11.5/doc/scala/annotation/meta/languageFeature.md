
#                    scala.annotation.meta.languageFeature                    #

```
final class languageFeature extends Annotation with StaticAnnotation
```

An annotation giving particulars for a language feature in object
 `scala.language` .

* Source
  * [languageFeature.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/annotation/meta/languageFeature.scala#L1)


--------------------------------------------------------------------------------
        Instance Constructors From scala.annotation.meta.languageFeature
--------------------------------------------------------------------------------


### `new languageFeature(feature: String, enableRequired: Boolean)`          ###
(defined at scala.annotation.meta.languageFeature)
