
#                         scala.annotation.meta.field                         #

```
final class field extends Annotation with StaticAnnotation
```

Consult the documentation in package scala.annotation.meta.

* Source
  * [field.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/annotation/meta/field.scala#L1)


--------------------------------------------------------------------------------
             Instance Constructors From scala.annotation.meta.field
--------------------------------------------------------------------------------


### `new field()`                                                            ###
(defined at scala.annotation.meta.field)
