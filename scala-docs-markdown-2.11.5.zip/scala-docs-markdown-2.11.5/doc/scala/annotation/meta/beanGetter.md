
#                       scala.annotation.meta.beanGetter                       #

```
final class beanGetter extends Annotation with StaticAnnotation
```

Consult the documentation in package scala.annotation.meta.

* Source
  * [beanGetter.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/annotation/meta/beanGetter.scala#L1)


--------------------------------------------------------------------------------
          Instance Constructors From scala.annotation.meta.beanGetter
--------------------------------------------------------------------------------


### `new beanGetter()`                                                       ###
(defined at scala.annotation.meta.beanGetter)
