
#                         scala.annotation.meta.param                         #

```
final class param extends Annotation with StaticAnnotation
```

Consult the documentation in package scala.annotation.meta.

* Source
  * [param.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/annotation/meta/param.scala#L1)


--------------------------------------------------------------------------------
             Instance Constructors From scala.annotation.meta.param
--------------------------------------------------------------------------------


### `new param()`                                                            ###
(defined at scala.annotation.meta.param)
