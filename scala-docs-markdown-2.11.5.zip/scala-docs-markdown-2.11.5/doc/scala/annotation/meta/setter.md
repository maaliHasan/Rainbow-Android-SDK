
#                         scala.annotation.meta.setter                         #

```
final class setter extends Annotation with StaticAnnotation
```

Consult the documentation in package scala.annotation.meta.

* Source
  * [setter.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/annotation/meta/setter.scala#L1)


--------------------------------------------------------------------------------
            Instance Constructors From scala.annotation.meta.setter
--------------------------------------------------------------------------------


### `new setter()`                                                           ###
(defined at scala.annotation.meta.setter)
