
#                    scala.annotation.meta.companionObject                    #

```
final class companionObject extends Annotation with StaticAnnotation
```

Currently unused; intended as an annotation target for classes such as case
classes that automatically generate a companion object

* Source
  * [companionObject.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/annotation/meta/companionObject.scala#L1)


--------------------------------------------------------------------------------
        Instance Constructors From scala.annotation.meta.companionObject
--------------------------------------------------------------------------------


### `new companionObject()`                                                  ###
(defined at scala.annotation.meta.companionObject)
