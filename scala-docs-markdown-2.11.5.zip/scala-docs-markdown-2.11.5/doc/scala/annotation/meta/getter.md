
#                         scala.annotation.meta.getter                         #

```
final class getter extends Annotation with StaticAnnotation
```

Consult the documentation in package scala.annotation.meta.

* Source
  * [getter.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/annotation/meta/getter.scala#L1)


--------------------------------------------------------------------------------
            Instance Constructors From scala.annotation.meta.getter
--------------------------------------------------------------------------------


### `new getter()`                                                           ###
(defined at scala.annotation.meta.getter)
