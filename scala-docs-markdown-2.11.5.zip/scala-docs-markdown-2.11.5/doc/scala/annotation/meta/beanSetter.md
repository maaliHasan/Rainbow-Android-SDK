
#                       scala.annotation.meta.beanSetter                       #

```
final class beanSetter extends Annotation with StaticAnnotation
```

Consult the documentation in package scala.annotation.meta.

* Source
  * [beanSetter.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/annotation/meta/beanSetter.scala#L1)


--------------------------------------------------------------------------------
          Instance Constructors From scala.annotation.meta.beanSetter
--------------------------------------------------------------------------------


### `new beanSetter()`                                                       ###
(defined at scala.annotation.meta.beanSetter)
