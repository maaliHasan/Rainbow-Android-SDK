
#                     scala.collection.GenTraversableOnce                     #

```
trait GenTraversableOnce[+A] extends Any
```

A template trait for all traversable-once objects which may be traversed in
parallel.

Methods in this trait are either abstract or can be implemented in terms of
other methods.

* Source
  * [GenTraversableOnce.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/GenTraversableOnce.scala#L1)


--------------------------------------------------------------------------------
                    Concrete Value Members From scala.Any###
--------------------------------------------------------------------------------


### `final def ##(): Int`                                                    ###

Equivalent to `x.hashCode` except for boxed numeric types and `null` . For
numerics, it returns a hash value which is consistent with value equality: if
two value type instances compare as true, then ## will produce the same hash
value for each of them. For `null` returns a hashcode where `null.hashCode`
throws a `NullPointerException` .

* returns
  * a hash value consistent with ==

* Definition Classes
  * Any

(defined at scala.Any###)


--------------------------------------------------------------------------------
        Abstract Value Members From scala.collection.GenTraversableOnce
--------------------------------------------------------------------------------


### `abstract def /:[B](z: B)(op: (B, A) ⇒ B): B`                            ###

Applies a binary operator to a start value and all elements of this collection
or iterator, going left to right.

Note: `/:` is alternate syntax for `foldLeft` ; `z /: xs` is the same as
 `xs foldLeft z` .

Examples:

Note that the folding function used to compute b is equivalent to that used to
compute c.

```scala
scala> val a = List(1,2,3,4)
a: List[Int] = List(1, 2, 3, 4)

scala> val b = (5 /: a)(_+_)
b: Int = 15

scala> val c = (5 /: a)((x,y) => x + y)
c: Int = 15
```

Note: will not terminate for infinite-sized collections.

Note: might return different results for different runs, unless the underlying
collection type is ordered or the operator is associative and commutative.

* B
  * the result type of the binary operator.
* z
  * the start value.
* op
  * the binary operator.
* returns
  * the result of inserting `op` between consecutive elements of this collection
    or iterator, going left to right with the start value `z` on the left:

    ```scala
    op(...op(op(z, x_1), x_2), ..., x_n)
    ```

    where `x1, ..., xn` are the elements of this collection or iterator.

(defined at scala.collection.GenTraversableOnce)


### `abstract def :\[B](z: B)(op: (A, B) ⇒ B): B`                            ###

Applies a binary operator to all elements of this collection or iterator and a
start value, going right to left.

Note: `:\` is alternate syntax for `foldRight` ; `xs :\ z` is the same as
 `xs foldRight z` .

Note: will not terminate for infinite-sized collections.

Note: might return different results for different runs, unless the underlying
collection type is ordered or the operator is associative and commutative.

Examples:

Note that the folding function used to compute b is equivalent to that used to
compute c.

```scala
scala> val a = List(1,2,3,4)
a: List[Int] = List(1, 2, 3, 4)

scala> val b = (a :\ 5)(_+_)
b: Int = 15

scala> val c = (a :\ 5)((x,y) => x + y)
c: Int = 15
```

* B
  * the result type of the binary operator.
* z
  * the start value
* op
  * the binary operator
* returns
  * the result of inserting `op` between consecutive elements of this collection
    or iterator, going right to left with the start value `z` on the right:

    ```scala
    op(x_1, op(x_2, ... op(x_n, z)...))
    ```

    where `x1, ..., xn` are the elements of this collection or iterator.

(defined at scala.collection.GenTraversableOnce)


### `abstract def aggregate[B](z: ⇒ B)(seqop: (B, A) ⇒ B, combop: (B, B) ⇒ B): B` ###

Aggregates the results of applying an operator to subsequent elements.

This is a more general form of `fold` and `reduce` . It has similar semantics,
but does not require the result to be a supertype of the element type. It
traverses the elements in different partitions sequentially, using `seqop` to
update the result, and then applies `combop` to results from different
partitions. The implementation of this operation may operate on an arbitrary
number of collection partitions, so `combop` may be invoked an arbitrary number
of times.

For example, one might want to process some elements and then produce a `Set` .
In this case, `seqop` would process an element and append it to the list, while
 `combop` would concatenate two lists from different partitions together. The
initial value `z` would be an empty set.

```scala
pc.aggregate(Set[Int]())(_ += process(_), _ ++ _)
```

Another example is calculating geometric mean from a collection of doubles (one
would typically require big doubles for this).

* B
  * the type of accumulated results
* z
  * the initial value for the accumulated result of the partition - this will
    typically be the neutral element for the `seqop` operator (e.g. `Nil` for
    list concatenation or `0` for summation) and may be evaluated more than once
* seqop
  * an operator used to accumulate results within a partition
* combop
  * an associative operator used to combine results from different partitions

(defined at scala.collection.GenTraversableOnce)


### `abstract def copyToArray[B >: A](xs: Array[B], start: Int, len: Int): Unit` ###

(defined at scala.collection.GenTraversableOnce)


### `abstract def count(p: (A) ⇒ Boolean): Int`                              ###

Counts the number of elements in the collection or iterator which satisfy a
predicate.

* p
  * the predicate used to test elements.
* returns
  * the number of elements satisfying the predicate `p` .

(defined at scala.collection.GenTraversableOnce)


### `abstract def exists(pred: (A) ⇒ Boolean): Boolean`                      ###

(defined at scala.collection.GenTraversableOnce)


### `abstract def find(pred: (A) ⇒ Boolean): Option[A]`                      ###

Finds the first element of the collection or iterator satisfying a predicate, if
any.

Note: may not terminate for infinite-sized collections.

Note: might return different results for different runs, unless the underlying
collection type is ordered.

* pred
  * the predicate used to test elements.
* returns
  * an option value containing the first element in the collection or iterator
    that satisfies `p` , or `None` if none exists.

(defined at scala.collection.GenTraversableOnce)


### `abstract def foldLeft[B](z: B)(op: (B, A) ⇒ B): B`                      ###

Applies a binary operator to a start value and all elements of this collection
or iterator, going left to right.

Note: will not terminate for infinite-sized collections.

Note: might return different results for different runs, unless the underlying
collection type is ordered or the operator is associative and commutative.

* B
  * the result type of the binary operator.
* z
  * the start value.
* op
  * the binary operator.
* returns
  * the result of inserting `op` between consecutive elements of this collection
    or iterator, going left to right with the start value `z` on the left:

    ```scala
    op(...op(z, x_1), x_2, ..., x_n)
    ```

    where `x1, ..., xn` are the elements of this collection or iterator.

(defined at scala.collection.GenTraversableOnce)


### `abstract def foldRight[B](z: B)(op: (A, B) ⇒ B): B`                     ###

Applies a binary operator to all elements of this collection or iterator and a
start value, going right to left.

Note: will not terminate for infinite-sized collections.

Note: might return different results for different runs, unless the underlying
collection type is ordered or the operator is associative and commutative.

* B
  * the result type of the binary operator.
* z
  * the start value.
* op
  * the binary operator.
* returns
  * the result of inserting `op` between consecutive elements of this collection
    or iterator, going right to left with the start value `z` on the right:

    ```scala
    op(x_1, op(x_2, ... op(x_n, z)...))
    ```

    where `x1, ..., xn` are the elements of this collection or iterator.

(defined at scala.collection.GenTraversableOnce)


### `abstract def fold[A1 >: A](z: A1)(op: (A1, A1) ⇒ A1): A1`               ###

Folds the elements of this collection or iterator using the specified
associative binary operator.

The order in which operations are performed on elements is unspecified and may
be nondeterministic.

* A1
  * a type parameter for the binary operator, a supertype of `A` .
* z
  * a neutral element for the fold operation; may be added to the result an
    arbitrary number of times, and must not change the result (e.g., `Nil` for
    list concatenation, 0 for addition, or 1 for multiplication.)
* op
  * a binary operator that must be associative
* returns
  * the result of applying fold operator `op` between all the elements and `z`

(defined at scala.collection.GenTraversableOnce)


### `abstract def forall(pred: (A) ⇒ Boolean): Boolean`                      ###

(defined at scala.collection.GenTraversableOnce)


### `abstract def foreach[U](f: (A) ⇒ U): Unit`                              ###

(defined at scala.collection.GenTraversableOnce)


### `abstract def hasDefiniteSize: Boolean`                                  ###

(defined at scala.collection.GenTraversableOnce)


### `abstract def isEmpty: Boolean`                                          ###

Tests whether the collection or iterator is empty.

* returns
  * `true` if the collection or iterator contains no elements, `false`
    otherwise.

(defined at scala.collection.GenTraversableOnce)


### `abstract def isTraversableAgain: Boolean`                               ###

Tests whether this collection or iterator can be repeatedly traversed. Always
true for Traversables and false for Iterators unless overridden.

* returns
  * `true` if it is repeatedly traversable, `false` otherwise.

(defined at scala.collection.GenTraversableOnce)


### `abstract def mkString(sep: String): String`                             ###

Displays all elements of this collection or iterator in a string using a
separator string.

* sep
  * the separator string.
* returns
  * a string representation of this collection or iterator. In the resulting
    string the string representations (w.r.t. the method `toString` ) of all
    elements of this collection or iterator are separated by the string `sep` .

Example:

```scala
List(1, 2, 3).mkString("|") = "1|2|3"
```

(defined at scala.collection.GenTraversableOnce)


### `abstract def mkString(start: String, sep: String, end: String): String` ###

Displays all elements of this collection or iterator in a string using start,
end, and separator strings.

* start
  * the starting string.
* sep
  * the separator string.
* end
  * the ending string.
* returns
  * a string representation of this collection or iterator. The resulting string
    begins with the string `start` and ends with the string `end` . Inside, the
    string representations (w.r.t. the method `toString` ) of all elements of
    this collection or iterator are separated by the string `sep` .

Example:

```scala
List(1, 2, 3).mkString("(", "; ", ")") = "(1; 2; 3)"
```

(defined at scala.collection.GenTraversableOnce)


### `abstract def mkString: String`                                          ###

Displays all elements of this collection or iterator in a string.

* returns
  * a string representation of this collection or iterator. In the resulting
    string the string representations (w.r.t. the method `toString` ) of all
    elements of this collection or iterator follow each other without any
    separator string.

(defined at scala.collection.GenTraversableOnce)


### `abstract def nonEmpty: Boolean`                                         ###

Tests whether the collection or iterator is not empty.

* returns
  * `true` if the collection or iterator contains at least one element, `false`
    otherwise.

(defined at scala.collection.GenTraversableOnce)


### `abstract def reduceLeftOption[B >: A](op: (B, A) ⇒ B): Option[B]`       ###

Optionally applies a binary operator to all elements of this collection or
iterator, going left to right.

Note: will not terminate for infinite-sized collections.

Note: might return different results for different runs, unless the underlying
collection type is ordered or the operator is associative and commutative.

* B
  * the result type of the binary operator.
* op
  * the binary operator.
* returns
  * an option value containing the result of `reduceLeft(op)` is this collection
    or iterator is nonempty, `None` otherwise.

(defined at scala.collection.GenTraversableOnce)


### `abstract def reduceOption[A1 >: A](op: (A1, A1) ⇒ A1): Option[A1]`      ###

Reduces the elements of this collection or iterator, if any, using the specified
associative binary operator.

The order in which operations are performed on elements is unspecified and may
be nondeterministic.

* A1
  * A type parameter for the binary operator, a supertype of `A` .
* op
  * A binary operator that must be associative.
* returns
  * An option value containing result of applying reduce operator `op` between
    all the elements if the collection is nonempty, and `None` otherwise.

(defined at scala.collection.GenTraversableOnce)


### `abstract def reduceRightOption[B >: A](op: (A, B) ⇒ B): Option[B]`      ###

Optionally applies a binary operator to all elements of this collection or
iterator, going right to left.

Note: will not terminate for infinite-sized collections.

Note: might return different results for different runs, unless the underlying
collection type is ordered or the operator is associative and commutative.

* B
  * the result type of the binary operator.
* op
  * the binary operator.
* returns
  * an option value containing the result of `reduceRight(op)` is this
    collection or iterator is nonempty, `None` otherwise.

(defined at scala.collection.GenTraversableOnce)


### `abstract def reduceRight[B >: A](op: (A, B) ⇒ B): B`                    ###

Applies a binary operator to all elements of this collection or iterator, going
right to left.

Note: will not terminate for infinite-sized collections.

Note: might return different results for different runs, unless the underlying
collection type is ordered or the operator is associative and commutative.

* B
  * the result type of the binary operator.
* op
  * the binary operator.
* returns
  * the result of inserting `op` between consecutive elements of this collection
    or iterator, going right to left:

    ```scala
    op(x_1, op(x_2, ..., op(x_{n-1}, x_n)...))
    ```

    where `x1, ..., xn` are the elements of this collection or iterator.

* Exceptions thrown
  * UnsupportedOperationException if this collection or iterator is empty.

(defined at scala.collection.GenTraversableOnce)


### `abstract def reduce[A1 >: A](op: (A1, A1) ⇒ A1): A1`                    ###

Reduces the elements of this collection or iterator using the specified
associative binary operator.

The order in which operations are performed on elements is unspecified and may
be nondeterministic.

* A1
  * A type parameter for the binary operator, a supertype of `A` .
* op
  * A binary operator that must be associative.
* returns
  * The result of applying reduce operator `op` between all the elements if the
    collection or iterator is nonempty.

* Exceptions thrown
  * UnsupportedOperationException if this collection or iterator is empty.

(defined at scala.collection.GenTraversableOnce)


### `abstract def seq: TraversableOnce[A]`                                   ###

(defined at scala.collection.GenTraversableOnce)


### `abstract def size: Int`                                                 ###

The size of this collection or iterator.

Note: will not terminate for infinite-sized collections.

* returns
  * the number of elements in this collection or iterator.

(defined at scala.collection.GenTraversableOnce)


### `abstract def toBuffer[A1 >: A]: Buffer[A1]`                             ###

Uses the contents of this collection or iterator to create a new mutable buffer.

Note: will not terminate for infinite-sized collections.

* returns
  * a buffer containing all elements of this collection or iterator.

(defined at scala.collection.GenTraversableOnce)


### `abstract def toIndexedSeq: immutable.IndexedSeq[A]`                     ###

Converts this collection or iterator to an indexed sequence.

Note: will not terminate for infinite-sized collections.

* returns
  * an indexed sequence containing all elements of this collection or iterator.

(defined at scala.collection.GenTraversableOnce)


### `abstract def toIterable: GenIterable[A]`                                ###

Converts this collection or iterator to an iterable collection. Note that the
choice of target `Iterable` is lazy in this default implementation as this
 `TraversableOnce` may be lazy and unevaluated (i.e. it may be an iterator which
is only traversable once).

Note: will not terminate for infinite-sized collections.

* returns
  * an `Iterable` containing all elements of this collection or iterator.

(defined at scala.collection.GenTraversableOnce)


### `abstract def toIterator: Iterator[A]`                                   ###

Returns an Iterator over the elements in this collection or iterator. Will
return the same Iterator if this instance is already an Iterator.

Note: will not terminate for infinite-sized collections.

* returns
  * an Iterator containing all elements of this collection or iterator.

(defined at scala.collection.GenTraversableOnce)


### `abstract def toList: List[A]`                                           ###

Converts this collection or iterator to a list.

Note: will not terminate for infinite-sized collections.

* returns
  * a list containing all elements of this collection or iterator.

(defined at scala.collection.GenTraversableOnce)


### `abstract def toSeq: GenSeq[A]`                                          ###

Converts this collection or iterator to a sequence. As with `toIterable` , it's
lazy in this default implementation, as this `TraversableOnce` may be lazy and
unevaluated.

Note: will not terminate for infinite-sized collections.

* returns
  * a sequence containing all elements of this collection or iterator.

(defined at scala.collection.GenTraversableOnce)


### `abstract def toSet[A1 >: A]: GenSet[A1]`                                ###

Converts this collection or iterator to a set.

Note: will not terminate for infinite-sized collections.

* returns
  * a set containing all elements of this collection or iterator.

(defined at scala.collection.GenTraversableOnce)


### `abstract def toStream: Stream[A]`                                       ###

Converts this collection or iterator to a stream.

* returns
  * a stream containing all elements of this collection or iterator.

(defined at scala.collection.GenTraversableOnce)


### `abstract def toTraversable: GenTraversable[A]`                          ###

Converts this collection or iterator to an unspecified Traversable. Will return
the same collection if this instance is already Traversable.

Note: will not terminate for infinite-sized collections.

* returns
  * a Traversable containing all elements of this collection or iterator.

(defined at scala.collection.GenTraversableOnce)


### `abstract def toVector: Vector[A]`                                       ###

Converts this collection or iterator to a Vector.

Note: will not terminate for infinite-sized collections.

* returns
  * a vector containing all elements of this collection or iterator.

(defined at scala.collection.GenTraversableOnce)


--------------------------------------------------------------------------------
        Concrete Value Members From scala.collection.GenTraversableOnce
--------------------------------------------------------------------------------


### `abstract def copyToArray[B >: A](xs: Array[B]): Unit`                   ###

[use case]

Copies values of this collection or iterator to an array. Fills the given array
 `xs` with values of this collection or iterator. Copying will stop once either
the end of the current collection or iterator is reached, or the end of the
array is reached.

Note: will not terminate for infinite-sized collections.

* xs
  * the array to fill.

(defined at scala.collection.GenTraversableOnce)


### `abstract def copyToArray[B >: A](xs: Array[B], start: Int): Unit`       ###

[use case]

Copies values of this collection or iterator to an array. Fills the given array
 `xs` with values of this collection or iterator, beginning at index `start` .
Copying will stop once either the end of the current collection or iterator is
reached, or the end of the array is reached.

Note: will not terminate for infinite-sized collections.

* xs
  * the array to fill.
* start
  * the starting index.

(defined at scala.collection.GenTraversableOnce)


### `abstract def max[A1 >: A](implicit ord: Ordering[A1]): A`               ###

[use case]

Finds the largest element.

* returns
  * the largest element of this collection or iterator.

(defined at scala.collection.GenTraversableOnce)


### `abstract def maxBy[B](f: (A) ⇒ B)(implicit cmp: Ordering[B]): A`        ###

[use case]

Finds the first element which yields the largest value measured by function f.

* B
  * The result type of the function f.
* f
  * The measuring function.
* returns
  * the first element of this collection or iterator with the largest value
    measured by function f.

(defined at scala.collection.GenTraversableOnce)


### `abstract def min[A1 >: A](implicit ord: Ordering[A1]): A`               ###

[use case]

Finds the smallest element.

* returns
  * the smallest element of this collection or iterator

(defined at scala.collection.GenTraversableOnce)


### `abstract def minBy[B](f: (A) ⇒ B)(implicit cmp: Ordering[B]): A`        ###

[use case]

Finds the first element which yields the smallest value measured by function f.

* B
  * The result type of the function f.
* f
  * The measuring function.
* returns
  * the first element of this collection or iterator with the smallest value
    measured by function f.

(defined at scala.collection.GenTraversableOnce)


### `abstract def product[A1 >: A](implicit num: Numeric[A1]): A1`           ###

[use case]

Multiplies up the elements of this collection.

* returns
  * the product of all elements in this collection or iterator of numbers of
    type `Int` . Instead of `Int` , any other type `T` with an implicit
     `Numeric[T]` implementation can be used as element type of the collection
    or iterator and as result type of `product` . Examples of such types are:
     `Long` , `Float` , `Double` , `BigInt` .

(defined at scala.collection.GenTraversableOnce)


### `abstract def sum[A1 >: A](implicit num: Numeric[A1]): A1`               ###

[use case]

Sums up the elements of this collection.

* returns
  * the sum of all elements in this collection or iterator of numbers of type
     `Int` . Instead of `Int` , any other type `T` with an implicit
     `Numeric[T]` implementation can be used as element type of the collection
    or iterator and as result type of `sum` . Examples of such types are:
     `Long` , `Float` , `Double` , `BigInt` .

(defined at scala.collection.GenTraversableOnce)


### `abstract def toArray[A1 >: A](implicit arg0: ClassTag[A1]): Array[A1]`  ###

[use case]

Converts this collection or iterator to an array.

Note: will not terminate for infinite-sized collections.

* returns
  * an array containing all elements of this collection or iterator. An
     `ClassTag` must be available for the element type of this collection or
    iterator.

(defined at scala.collection.GenTraversableOnce)


### `abstract def toMap[K, V](implicit ev: <:<[A, (K, V)]): GenMap[K, V]`    ###

[use case]

Converts this collection or iterator to a map. This method is unavailable unless
the elements are members of Tuple2, each ((T, U)) becoming a key-value pair in
the map. Duplicate keys will be overwritten by later keys: if this is an
unordered collection, which key is in the resulting map is undefined.

Note: will not terminate for infinite-sized collections.

* returns
  * a map of type `immutable.Map[T, U]` containing all key/value pairs of type
     `(T, U)` of this collection or iterator.

(defined at scala.collection.GenTraversableOnce)


### `abstract def to[Col[_]](implicit cbf: CanBuildFrom[Nothing, A, Col[A]]): Col[A]` ###

[use case]

Converts this collection or iterator into another by copying all elements.

Note: will not terminate for infinite-sized collections.

* Col
  * The collection type to build.
* returns
  * a new collection containing all elements of this collection or iterator.
(defined at scala.collection.GenTraversableOnce)
