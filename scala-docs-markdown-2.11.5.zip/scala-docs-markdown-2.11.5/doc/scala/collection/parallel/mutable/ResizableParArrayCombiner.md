
#         scala.collection.parallel.mutable.ResizableParArrayCombiner         #

```
trait ResizableParArrayCombiner[T] extends LazyCombiner[T, ParArray[T], ExposedArrayBuffer[T]]
```

An array combiner that uses a chain of arraybuffers to store elements.

* Source
  * [ResizableParArrayCombiner.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/parallel/mutable/ResizableParArrayCombiner.scala#L1)


--------------------------------------------------------------------------------
                                  Type Members
--------------------------------------------------------------------------------


### `class CopyChainToArray extends Task[Unit, CopyChainToArray]`            ###

* Source
  * [ResizableParArrayCombiner.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/parallel/mutable/ResizableParArrayCombiner.scala#L1)


--------------------------------------------------------------------------------
         Concrete Value Members From scala.collection.generic.Growable
--------------------------------------------------------------------------------


### `def ++=(xs: TraversableOnce[T]): ResizableParArrayCombiner.this.type`   ###

adds all elements produced by a TraversableOnce to this growable collection.

* xs
  * the TraversableOnce producing the elements to add.
* returns
  * the growable collection itself.

* Definition Classes
  * Growable

(defined at scala.collection.generic.Growable)


### `def +=(elem1: T, elem2: T, elems: T*): ResizableParArrayCombiner.this.type` ###

adds two or more elements to this growable collection.

* elem1
  * the first element to add.
* elem2
  * the second element to add.
* elems
  * the remaining elements to add.
* returns
  * the growable collection itself

* Definition Classes
  * Growable

(defined at scala.collection.generic.Growable)


--------------------------------------------------------------------------------
          Concrete Value Members From scala.collection.mutable.Builder
--------------------------------------------------------------------------------


### `def mapResult[NewTo](f: (ParArray[T]) ⇒ NewTo): Builder[T, NewTo]`      ###

Creates a new builder by applying a transformation function to the results of
this builder.

* NewTo
  * the type of collection returned by `f` .
* f
  * the transformation function.
* returns
  * a new builder which is the same as the current builder except that a
    transformation function is applied to this builder's result.

* Definition Classes
  * Builder

(defined at scala.collection.mutable.Builder)


### `def sizeHint(coll: TraversableLike[_, _]): Unit`                        ###

Gives a hint that one expects the `result` of this builder to have the same size
as the given collection, plus some delta. This will provide a hint only if the
collection is known to have a cheap `size` method. Currently this is assumed to
be the case if and only if the collection is of type `IndexedSeqLike` . Some
builder classes will optimize their representation based on the hint. However,
builder implementations are still required to work correctly even if the hint is
wrong, i.e. a different number of elements is added.

* coll
  * the collection which serves as a hint for the result's size.

* Definition Classes
  * Builder

(defined at scala.collection.mutable.Builder)


### `def sizeHint(coll: TraversableLike[_, _], delta: Int): Unit`            ###

Gives a hint that one expects the `result` of this builder to have the same size
as the given collection, plus some delta. This will provide a hint only if the
collection is known to have a cheap `size` method. Currently this is assumed to
be the case if and only if the collection is of type `IndexedSeqLike` . Some
builder classes will optimize their representation based on the hint. However,
builder implementations are still required to work correctly even if the hint is
wrong, i.e. a different number of elements is added.

* coll
  * the collection which serves as a hint for the result's size.
* delta
  * a correction to add to the `coll.size` to produce the size hint.

* Definition Classes
  * Builder

(defined at scala.collection.mutable.Builder)


### `def sizeHintBounded(size: Int, boundingColl: TraversableLike[_, _]): Unit` ###

Gives a hint how many elements are expected to be added when the next `result`
is called, together with an upper bound given by the size of some other
collection. Some builder classes will optimize their representation based on the
hint. However, builder implementations are still required to work correctly even
if the hint is wrong, i.e. a different number of elements is added.

* size
  * the hint how many elements will be added.
* boundingColl
  * the bounding collection. If it is an IndexedSeqLike, then sizes larger than
    collection's size are reduced.

* Definition Classes
  * Builder

(defined at scala.collection.mutable.Builder)


--------------------------------------------------------------------------------
         Concrete Value Members From scala.collection.parallel.Combiner
--------------------------------------------------------------------------------


### `var _combinerTaskSupport: TaskSupport`                                  ###

* Definition Classes
  * Combiner

(defined at scala.collection.parallel.Combiner)


### `def canBeShared: Boolean`                                               ###

Returns `true` if this combiner has a thread-safe `+=` and is meant to be shared
across several threads constructing the collection.

By default, this method returns `false` .

* Definition Classes
  * Combiner

(defined at scala.collection.parallel.Combiner)


### `def combinerTaskSupport: TaskSupport`                                   ###

* Definition Classes
  * Combiner

(defined at scala.collection.parallel.Combiner)


### `def combinerTaskSupport_=(cts: TaskSupport): Unit`                      ###

* Definition Classes
  * Combiner

(defined at scala.collection.parallel.Combiner)


### `def resultWithTaskSupport: ParArray[T]`                                 ###

Constructs the result and sets the appropriate tasksupport object to the
resulting collection if this is applicable.

* Definition Classes
  * Combiner

(defined at scala.collection.parallel.Combiner)


--------------------------------------------------------------------------------
   Abstract Value Members From scala.collection.parallel.mutable.LazyCombiner
--------------------------------------------------------------------------------


### `abstract val chain: ArrayBuffer[ExposedArrayBuffer[T]]`                 ###

* Definition Classes
  * LazyCombiner

(defined at scala.collection.parallel.mutable.LazyCombiner)


--------------------------------------------------------------------------------
   Concrete Value Members From scala.collection.parallel.mutable.LazyCombiner
--------------------------------------------------------------------------------


### `def +=(elem: T): ResizableParArrayCombiner.this.type`                   ###

Adds a single element to the builder.

* elem
  * the element to be added.
* returns
  * the builder itself.

* Definition Classes
  * LazyCombiner → Builder → Growable

(defined at scala.collection.parallel.mutable.LazyCombiner)


### `def clear(): Unit`                                                      ###

Clears the contents of this builder. After execution of this method the builder
will contain no elements.

* Definition Classes
  * LazyCombiner → Builder → Growable → Clearable

(defined at scala.collection.parallel.mutable.LazyCombiner)


### `def combine[N <: T, NewTo >: ParArray[T]](other: Combiner[N, NewTo]): Combiner[N, NewTo]` ###

Combines the contents of the receiver builder and the `other` builder, producing
a new builder containing both their elements.

This method may combine the two builders by copying them into a larger
collection, by producing a lazy view that gets evaluated once `result` is
invoked, or use a merge operation specific to the data structure in question.

Note that both the receiver builder and `other` builder become invalidated after
the invocation of this method, and should be cleared (see `clear` ) if they are
to be used again.

Also, combining two combiners `c1` and `c2` for which `c1 eq c2` is `true` ,
that is, they are the same objects in memory:

```scala
c1.combine(c2)
```

always does nothing and returns `c1` .

* N
  * the type of elements contained by the `other` builder
* NewTo
  * the type of collection produced by the `other` builder
* other
  * the other builder
* returns
  * the parallel builder containing both the elements of this and the `other`
    builder

* Definition Classes
  * LazyCombiner → Combiner

(defined at scala.collection.parallel.mutable.LazyCombiner)


### `val lastbuff: ExposedArrayBuffer[T]`                                    ###

* Definition Classes
  * LazyCombiner

(defined at scala.collection.parallel.mutable.LazyCombiner)


### `def result(): ParArray[T]`                                              ###

Produces a collection from the added elements. The builder's contents are
undefined after this operation.

* returns
  * a collection containing the elements added to this builder.

* Definition Classes
  * LazyCombiner → Builder

(defined at scala.collection.parallel.mutable.LazyCombiner)


### `def size: Int`                                                          ###

* Definition Classes
  * LazyCombiner → Sizing

(defined at scala.collection.parallel.mutable.LazyCombiner)


--------------------------------------------------------------------------------
Concrete Value Members From scala.collection.parallel.mutable.ResizableParArrayCombiner
--------------------------------------------------------------------------------


### `def allocateAndCopy: ParArray[T]`                                       ###

Method that allocates the data structure and copies elements into it using
 `size` and `chain` members.

* Definition Classes
  * ResizableParArrayCombiner → LazyCombiner

(defined at scala.collection.parallel.mutable.ResizableParArrayCombiner)


### `final def newLazyCombiner(c: ArrayBuffer[ExposedArrayBuffer[T]]): ResizableParArrayCombiner[T]` ###

* Definition Classes
  * ResizableParArrayCombiner → LazyCombiner

(defined at scala.collection.parallel.mutable.ResizableParArrayCombiner)


### `def sizeHint(sz: Int): Unit`                                            ###

Gives a hint how many elements are expected to be added when the next `result`
is called. Some builder classes will optimize their representation based on the
hint. However, builder implementations are still required to work correctly even
if the hint is wrong, i.e. a different number of elements is added.

* Definition Classes
  * ResizableParArrayCombiner → Builder

(defined at scala.collection.parallel.mutable.ResizableParArrayCombiner)


### `def toString(): String`                                                 ###

Creates a String representation of this object. The default representation is
platform dependent. On the java platform it is the concatenation of the class
name, "@", and the object's hashcode in hexadecimal.

* returns
  * a String representation of the object.

* Definition Classes
  * ResizableParArrayCombiner → AnyRef → Any

(defined at scala.collection.parallel.mutable.ResizableParArrayCombiner)


--------------------------------------------------------------------------------
Concrete Value Members From Implicit scala.collection.parallel.CollectionsHaveToParArray
--------------------------------------------------------------------------------


### `def toParArray: ParArray[T]`                                            ###

* Implicit information
  * This member is added by an implicit conversion from
    ResizableParArrayCombiner [T] to CollectionsHaveToParArray [
    ResizableParArrayCombiner [T], T] performed by method
    CollectionsHaveToParArray in scala.collection.parallel. This conversion will
    take place only if an implicit value of type (ResizableParArrayCombiner [T])
    ⇒ GenTraversableOnce [T] is in scope.
* Definition Classes
  * CollectionsHaveToParArray
(added by implicit convertion: scala.collection.parallel.CollectionsHaveToParArray)
