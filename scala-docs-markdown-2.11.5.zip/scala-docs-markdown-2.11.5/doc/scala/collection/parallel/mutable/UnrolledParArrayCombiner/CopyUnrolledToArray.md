
# scala.collection.parallel.mutable.UnrolledParArrayCombiner#CopyUnrolledToArray #

```
class CopyUnrolledToArray extends Task[Unit, CopyUnrolledToArray]
```

* Source
  * [UnrolledParArrayCombiner.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/parallel/mutable/UnrolledParArrayCombiner.scala#L1)


--------------------------------------------------------------------------------
                                  Type Members
--------------------------------------------------------------------------------


### `type Result = Unit`                                                     ###

* Definition Classes
  * Task


--------------------------------------------------------------------------------
               Value Members From scala.collection.parallel.Task
--------------------------------------------------------------------------------


### `def forwardThrowable(): Unit`                                           ###

* Definition Classes
  * Task

(defined at scala.collection.parallel.Task)


### `def repr: CopyUnrolledToArray`                                          ###

* Definition Classes
  * Task

(defined at scala.collection.parallel.Task)


### `var throwable: Throwable`                                               ###

* Definition Classes
  * Task

(defined at scala.collection.parallel.Task)


--------------------------------------------------------------------------------
Instance Constructors From scala.collection.parallel.mutable.UnrolledParArrayCombiner.CopyUnrolledToArray
--------------------------------------------------------------------------------


### `new CopyUnrolledToArray(array: Array[Any], offset: Int, howmany: Int)`  ###

(defined at scala.collection.parallel.mutable.UnrolledParArrayCombiner.CopyUnrolledToArray)


--------------------------------------------------------------------------------
Value Members From scala.collection.parallel.mutable.UnrolledParArrayCombiner.CopyUnrolledToArray
--------------------------------------------------------------------------------


### `def leaf(prev: Option[Unit]): Unit`                                     ###

Body of the task - non-divisible unit of work done by this task. Optionally is
provided with the result from the previous completed task or `None` if there was
no previous task (or the previous task is uncompleted or unknown).

* Definition Classes
  * CopyUnrolledToArray → Task

(defined at scala.collection.parallel.mutable.UnrolledParArrayCombiner.CopyUnrolledToArray)


### `var result: Unit`                                                       ###

A result that can be accessed once the task is completed.

* Definition Classes
  * CopyUnrolledToArray → Task

(defined at scala.collection.parallel.mutable.UnrolledParArrayCombiner.CopyUnrolledToArray)


### `def shouldSplitFurther: Boolean`                                        ###

Decides whether or not this task should be split further.

* Definition Classes
  * CopyUnrolledToArray → Task

(defined at scala.collection.parallel.mutable.UnrolledParArrayCombiner.CopyUnrolledToArray)


### `def split: immutable.List[CopyUnrolledToArray]`                         ###

Splits this task into a list of smaller tasks.

* Definition Classes
  * CopyUnrolledToArray → Task

(defined at scala.collection.parallel.mutable.UnrolledParArrayCombiner.CopyUnrolledToArray)


### `def toString(): String`                                                 ###

Creates a String representation of this object. The default representation is
platform dependent. On the java platform it is the concatenation of the class
name, "@", and the object's hashcode in hexadecimal.

* returns
  * a String representation of the object.

* Definition Classes
  * CopyUnrolledToArray → AnyRef → Any

(defined at scala.collection.parallel.mutable.UnrolledParArrayCombiner.CopyUnrolledToArray)


--------------------------------------------------------------------------------
Value Members From Implicit scala.collection.parallel.CollectionsHaveToParArray
--------------------------------------------------------------------------------


### `def toParArray: ParArray[T]`                                            ###

* Implicit information
  * This member is added by an implicit conversion from CopyUnrolledToArray to
    CollectionsHaveToParArray [CopyUnrolledToArray, T] performed by method
    CollectionsHaveToParArray in scala.collection.parallel. This conversion will
    take place only if an implicit value of type (CopyUnrolledToArray) ⇒
    GenTraversableOnce [T] is in scope.
* Definition Classes
  * CollectionsHaveToParArray
(added by implicit convertion: scala.collection.parallel.CollectionsHaveToParArray)
