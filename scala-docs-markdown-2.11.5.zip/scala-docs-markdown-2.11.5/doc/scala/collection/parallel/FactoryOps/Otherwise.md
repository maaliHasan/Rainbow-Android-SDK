
#                scala.collection.parallel.FactoryOps#Otherwise                #

```
trait Otherwise[R] extends AnyRef
```

* Source
  * [package.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/parallel/package.scala#L1)


--------------------------------------------------------------------------------
   Abstract Value Members From scala.collection.parallel.FactoryOps.Otherwise
--------------------------------------------------------------------------------


### `abstract def otherwise(notbody: ⇒ R): R`                                ###

(defined at scala.collection.parallel.FactoryOps.Otherwise)


--------------------------------------------------------------------------------
Concrete Value Members From Implicit scala.collection.parallel.CollectionsHaveToParArray
--------------------------------------------------------------------------------


### `def toParArray: ParArray[T]`                                            ###

* Implicit information
  * This member is added by an implicit conversion from Otherwise [R] to
    CollectionsHaveToParArray [Otherwise [R], T] performed by method
    CollectionsHaveToParArray in scala.collection.parallel. This conversion will
    take place only if an implicit value of type (Otherwise [R]) ⇒
    GenTraversableOnce [T] is in scope.
* Definition Classes
  * CollectionsHaveToParArray
(added by implicit convertion: scala.collection.parallel.CollectionsHaveToParArray)
