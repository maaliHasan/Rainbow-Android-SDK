
#             scala.collection.parallel.immutable.HashSetCombiner             #

```
object HashSetCombiner
```

* Source
  * [ParHashSet.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/parallel/immutable/ParHashSet.scala#L1)


--------------------------------------------------------------------------------
     Value Members From scala.collection.parallel.immutable.HashSetCombiner
--------------------------------------------------------------------------------


### `def apply[T]: HashSetCombiner[T]`                                       ###
(defined at scala.collection.parallel.immutable.HashSetCombiner)
