
#   scala.collection.parallel.AdaptiveWorkStealingForkJoinTasks#WrappedTask   #

```
class WrappedTask[R, Tp] extends RecursiveAction with AdaptiveWorkStealingForkJoinTasks.WrappedTask[R, Tp] with AdaptiveWorkStealingForkJoinTasks.WrappedTask[R, Tp]
```

* Source
  * [Tasks.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/parallel/Tasks.scala#L1)


--------------------------------------------------------------------------------
Instance Constructors From scala.collection.parallel.AdaptiveWorkStealingForkJoinTasks.WrappedTask
--------------------------------------------------------------------------------


### `new WrappedTask(body: Task[R, Tp])`                                     ###

(defined at scala.collection.parallel.AdaptiveWorkStealingForkJoinTasks.WrappedTask)


--------------------------------------------------------------------------------
Value Members From scala.collection.parallel.AdaptiveWorkStealingForkJoinTasks.WrappedTask
--------------------------------------------------------------------------------


### `val body: Task[R, Tp]`                                                  ###

the body of this task - what it executes, how it gets split and how results are
merged.

* Definition Classes
  * WrappedTask → WrappedTask

(defined at scala.collection.parallel.AdaptiveWorkStealingForkJoinTasks.WrappedTask)


### `def split: scala.Seq[AdaptiveWorkStealingForkJoinTasks.WrappedTask[R, Tp]]` ###

* Definition Classes
  * WrappedTask → WrappedTask → WrappedTask

(defined at scala.collection.parallel.AdaptiveWorkStealingForkJoinTasks.WrappedTask)


--------------------------------------------------------------------------------
Value Members From scala.collection.parallel.AdaptiveWorkStealingTasks.WrappedTask
--------------------------------------------------------------------------------


### `def compute(): Unit`                                                    ###

Code that gets called after the task gets started - it may spawn other tasks
instead of calling `leaf` .

* Definition Classes
  * WrappedTask → WrappedTask

(defined at scala.collection.parallel.AdaptiveWorkStealingTasks.WrappedTask)


### `def internal(): Unit`                                                   ###

* Definition Classes
  * WrappedTask

(defined at scala.collection.parallel.AdaptiveWorkStealingTasks.WrappedTask)


### `var next: AdaptiveWorkStealingForkJoinTasks.WrappedTask[R, Tp]`         ###

* Definition Classes
  * WrappedTask

(defined at scala.collection.parallel.AdaptiveWorkStealingTasks.WrappedTask)


### `def printChain(): Unit`                                                 ###

* Definition Classes
  * WrappedTask

(defined at scala.collection.parallel.AdaptiveWorkStealingTasks.WrappedTask)


### `var shouldWaitFor: Boolean`                                             ###

* Definition Classes
  * WrappedTask

(defined at scala.collection.parallel.AdaptiveWorkStealingTasks.WrappedTask)


### `def spawnSubtasks(): AdaptiveWorkStealingForkJoinTasks.WrappedTask[R, Tp]` ###

* Definition Classes
  * WrappedTask

(defined at scala.collection.parallel.AdaptiveWorkStealingTasks.WrappedTask)


--------------------------------------------------------------------------------
     Value Members From scala.collection.parallel.ForkJoinTasks.WrappedTask
--------------------------------------------------------------------------------


### `def start(): Unit`                                                      ###

Start task.

* Definition Classes
  * WrappedTask → WrappedTask

(defined at scala.collection.parallel.ForkJoinTasks.WrappedTask)


### `def sync(): Unit`                                                       ###

Wait for task to finish.

* Definition Classes
  * WrappedTask → WrappedTask

(defined at scala.collection.parallel.ForkJoinTasks.WrappedTask)


### `def tryCancel(): Boolean`                                               ###

Try to cancel the task.

* returns
  * `true` if cancellation is successful.

* Definition Classes
  * WrappedTask → WrappedTask

(defined at scala.collection.parallel.ForkJoinTasks.WrappedTask)


--------------------------------------------------------------------------------
         Value Members From scala.collection.parallel.Tasks.WrappedTask
--------------------------------------------------------------------------------


### `def release(): Unit`                                                    ###

If the task has been cancelled successfully, those syncing on it may
automatically be notified, depending on the implementation. If they aren't, this
release method should be called after processing the cancelled task.

This method may be overridden.

* Definition Classes
  * WrappedTask

(defined at scala.collection.parallel.Tasks.WrappedTask)


--------------------------------------------------------------------------------
           Value Members From scala.concurrent.forkjoin.ForkJoinTask
--------------------------------------------------------------------------------


### `def cancel(arg0: Boolean): Boolean`                                     ###

* Definition Classes
  * ForkJoinTask → Future

(defined at scala.concurrent.forkjoin.ForkJoinTask)


### `final def compareAndSetForkJoinTaskTag(arg0: Short, arg1: Short): Boolean` ###

* Definition Classes
  * ForkJoinTask

(defined at scala.concurrent.forkjoin.ForkJoinTask)


### `def complete(arg0: Void): Unit`                                         ###

* Definition Classes
  * ForkJoinTask

(defined at scala.concurrent.forkjoin.ForkJoinTask)


### `def completeExceptionally(arg0: java.lang.Throwable): Unit`             ###

* Definition Classes
  * ForkJoinTask

(defined at scala.concurrent.forkjoin.ForkJoinTask)


### `final def fork(): ForkJoinTask[Void]`                                   ###

* Definition Classes
  * ForkJoinTask

(defined at scala.concurrent.forkjoin.ForkJoinTask)


### `final def get(): Void`                                                  ###

* Definition Classes
  * ForkJoinTask → Future
* Annotations
  * @ throws (...) @ throws (...)

(defined at scala.concurrent.forkjoin.ForkJoinTask)


### `final def get(arg0: Long, arg1: TimeUnit): Void`                        ###

* Definition Classes
  * ForkJoinTask → Future
* Annotations
  * @ throws (...) @ throws (...) @ throws (...)

(defined at scala.concurrent.forkjoin.ForkJoinTask)


### `final def getException(): java.lang.Throwable`                          ###

* Definition Classes
  * ForkJoinTask

(defined at scala.concurrent.forkjoin.ForkJoinTask)


### `final def getForkJoinTaskTag(): Short`                                  ###

* Definition Classes
  * ForkJoinTask

(defined at scala.concurrent.forkjoin.ForkJoinTask)


### `final def invoke(): Void`                                               ###

* Definition Classes
  * ForkJoinTask

(defined at scala.concurrent.forkjoin.ForkJoinTask)


### `final def isCancelled(): Boolean`                                       ###

* Definition Classes
  * ForkJoinTask → Future

(defined at scala.concurrent.forkjoin.ForkJoinTask)


### `final def isCompletedAbnormally(): Boolean`                             ###

* Definition Classes
  * ForkJoinTask

(defined at scala.concurrent.forkjoin.ForkJoinTask)


### `final def isCompletedNormally(): Boolean`                               ###

* Definition Classes
  * ForkJoinTask

(defined at scala.concurrent.forkjoin.ForkJoinTask)


### `final def isDone(): Boolean`                                            ###

* Definition Classes
  * ForkJoinTask → Future

(defined at scala.concurrent.forkjoin.ForkJoinTask)


### `final def join(): Void`                                                 ###

* Definition Classes
  * ForkJoinTask

(defined at scala.concurrent.forkjoin.ForkJoinTask)


### `final def quietlyComplete(): Unit`                                      ###

* Definition Classes
  * ForkJoinTask

(defined at scala.concurrent.forkjoin.ForkJoinTask)


### `final def quietlyInvoke(): Unit`                                        ###

* Definition Classes
  * ForkJoinTask

(defined at scala.concurrent.forkjoin.ForkJoinTask)


### `final def quietlyJoin(): Unit`                                          ###

* Definition Classes
  * ForkJoinTask

(defined at scala.concurrent.forkjoin.ForkJoinTask)


### `def reinitialize(): Unit`                                               ###

* Definition Classes
  * ForkJoinTask

(defined at scala.concurrent.forkjoin.ForkJoinTask)


### `final def setForkJoinTaskTag(arg0: Short): Short`                       ###

* Definition Classes
  * ForkJoinTask

(defined at scala.concurrent.forkjoin.ForkJoinTask)


### `def tryUnfork(): Boolean`                                               ###

* Definition Classes
  * ForkJoinTask

(defined at scala.concurrent.forkjoin.ForkJoinTask)


--------------------------------------------------------------------------------
          Value Members From scala.concurrent.forkjoin.RecursiveAction
--------------------------------------------------------------------------------


### `final def exec(): Boolean`                                              ###

* Attributes
  * protected[scala.concurrent.forkjoin]
* Definition Classes
  * RecursiveAction → ForkJoinTask

(defined at scala.concurrent.forkjoin.RecursiveAction)


### `final def getRawResult(): Void`                                         ###

* Definition Classes
  * RecursiveAction → ForkJoinTask

(defined at scala.concurrent.forkjoin.RecursiveAction)


### `final def setRawResult(arg0: Void): Unit`                               ###

* Attributes
  * protected[scala.concurrent.forkjoin]
* Definition Classes
  * RecursiveAction → ForkJoinTask

(defined at scala.concurrent.forkjoin.RecursiveAction)


--------------------------------------------------------------------------------
Value Members From Implicit scala.collection.parallel.CollectionsHaveToParArray
--------------------------------------------------------------------------------


### `def toParArray: ParArray[T]`                                            ###

* Implicit information
  * This member is added by an implicit conversion from WrappedTask [R, Tp] to
    CollectionsHaveToParArray [WrappedTask [R, Tp], T] performed by method
    CollectionsHaveToParArray in scala.collection.parallel. This conversion will
    take place only if an implicit value of type (WrappedTask [R, Tp]) ⇒
    GenTraversableOnce [T] is in scope.
* Definition Classes
  * CollectionsHaveToParArray
(added by implicit convertion: scala.collection.parallel.CollectionsHaveToParArray)
