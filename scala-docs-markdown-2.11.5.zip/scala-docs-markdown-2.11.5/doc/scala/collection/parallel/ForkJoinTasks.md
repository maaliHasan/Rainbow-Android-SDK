
#                   scala.collection.parallel.ForkJoinTasks                   #

```
object ForkJoinTasks
```

* Source
  * [Tasks.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/parallel/Tasks.scala#L1)


--------------------------------------------------------------------------------
           Value Members From scala.collection.parallel.ForkJoinTasks
--------------------------------------------------------------------------------


### `lazy val defaultForkJoinPool: ForkJoinPool`                             ###
(defined at scala.collection.parallel.ForkJoinTasks)
