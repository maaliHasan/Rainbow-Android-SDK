
#              scala.collection.parallel.ParIterableLike#Collect              #

```
class Collect[S, That] extends Transformer[Combiner[S, That], Collect[S, That]]
```

* Attributes
  * protected[this]
* Source
  * [ParIterableLike.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/parallel/ParIterableLike.scala#L1)


--------------------------------------------------------------------------------
                                  Type Members
--------------------------------------------------------------------------------


### `type Result = Combiner[S, That]`                                        ###

* Definition Classes
  * Task


--------------------------------------------------------------------------------
     Value Members From scala.collection.parallel.ParIterableLike.Accessor
--------------------------------------------------------------------------------


### `def shouldSplitFurther: Boolean`                                        ###

Decides whether or not this task should be split further.

* Definition Classes
  * Accessor → Task

(defined at scala.collection.parallel.ParIterableLike.Accessor)


### `def split: scala.Seq[Task[Combiner[S, That], Collect[S, That]]]`        ###

Splits this task into a list of smaller tasks.

* Definition Classes
  * Accessor → Task

(defined at scala.collection.parallel.ParIterableLike.Accessor)


### `def toString(): String`                                                 ###

Creates a String representation of this object. The default representation is
platform dependent. On the java platform it is the concatenation of the class
name, "@", and the object's hashcode in hexadecimal.

* returns
  * a String representation of the object.

* Definition Classes
  * Accessor → AnyRef → Any

(defined at scala.collection.parallel.ParIterableLike.Accessor)


--------------------------------------------------------------------------------
  Instance Constructors From scala.collection.parallel.ParIterableLike.Collect
--------------------------------------------------------------------------------


### `new Collect(pf: PartialFunction[T, S], pbf: CombinerFactory[S, That], pit: IterableSplitter[T])` ###

(defined at scala.collection.parallel.ParIterableLike.Collect)


--------------------------------------------------------------------------------
      Value Members From scala.collection.parallel.ParIterableLike.Collect
--------------------------------------------------------------------------------


### `def leaf(prev: Option[Combiner[S, That]]): Unit`                        ###

Body of the task - non-divisible unit of work done by this task. Optionally is
provided with the result from the previous completed task or `None` if there was
no previous task (or the previous task is uncompleted or unknown).

* Definition Classes
  * Collect → Task

(defined at scala.collection.parallel.ParIterableLike.Collect)


### `def merge(that: Collect[S, That]): Unit`                                ###

Read of results of `that` task and merge them into results of this one.

* Definition Classes
  * Collect → Task

(defined at scala.collection.parallel.ParIterableLike.Collect)


### `def newSubtask(p: IterableSplitter[T]): Collect[S, That]`               ###

* Attributes
  * protected[this]
* Definition Classes
  * Collect → Accessor

(defined at scala.collection.parallel.ParIterableLike.Collect)


### `val pit: IterableSplitter[T]`                                           ###

* Attributes
  * protected[this]
* Definition Classes
  * Collect → Accessor

(defined at scala.collection.parallel.ParIterableLike.Collect)


### `var result: Combiner[S, That]`                                          ###

A result that can be accessed once the task is completed.

* Definition Classes
  * Collect → Task

(defined at scala.collection.parallel.ParIterableLike.Collect)


--------------------------------------------------------------------------------
Value Members From scala.collection.parallel.ParIterableLike.StrictSplitterCheckTask
--------------------------------------------------------------------------------


### `def requiresStrictSplitters: Boolean`                                   ###

* Definition Classes
  * StrictSplitterCheckTask

(defined at scala.collection.parallel.ParIterableLike.StrictSplitterCheckTask)


--------------------------------------------------------------------------------
               Value Members From scala.collection.parallel.Task
--------------------------------------------------------------------------------


### `def forwardThrowable(): Unit`                                           ###

* Definition Classes
  * Task

(defined at scala.collection.parallel.Task)


### `def repr: Collect[S, That]`                                             ###

* Definition Classes
  * Task

(defined at scala.collection.parallel.Task)


### `var throwable: Throwable`                                               ###

* Definition Classes
  * Task

(defined at scala.collection.parallel.Task)


--------------------------------------------------------------------------------
Value Members From Implicit scala.collection.parallel.CollectionsHaveToParArray
--------------------------------------------------------------------------------


### `def toParArray: ParArray[T]`                                            ###

* Implicit information
  * This member is added by an implicit conversion from Collect [S, That] to
    CollectionsHaveToParArray [Collect [S, That], T] performed by method
    CollectionsHaveToParArray in scala.collection.parallel. This conversion will
    take place only if an implicit value of type (Collect [S, That]) ⇒
    GenTraversableOnce [T] is in scope.
* Definition Classes
  * CollectionsHaveToParArray
(added by implicit convertion: scala.collection.parallel.CollectionsHaveToParArray)
