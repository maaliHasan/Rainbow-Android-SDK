
#            scala.collection.parallel.ParIterableLike#CopyToArray            #

```
class CopyToArray[U >: T, This >: Repr] extends Accessor[Unit, CopyToArray[U, This]]
```

* Attributes
  * protected[this]
* Source
  * [ParIterableLike.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/parallel/ParIterableLike.scala#L1)


--------------------------------------------------------------------------------
                                  Type Members
--------------------------------------------------------------------------------


### `type Result = Unit`                                                     ###

* Definition Classes
  * Task


--------------------------------------------------------------------------------
     Value Members From scala.collection.parallel.ParIterableLike.Accessor
--------------------------------------------------------------------------------


### `def shouldSplitFurther: Boolean`                                        ###

Decides whether or not this task should be split further.

* Definition Classes
  * Accessor → Task

(defined at scala.collection.parallel.ParIterableLike.Accessor)


### `def toString(): String`                                                 ###

Creates a String representation of this object. The default representation is
platform dependent. On the java platform it is the concatenation of the class
name, "@", and the object's hashcode in hexadecimal.

* returns
  * a String representation of the object.

* Definition Classes
  * Accessor → AnyRef → Any

(defined at scala.collection.parallel.ParIterableLike.Accessor)


--------------------------------------------------------------------------------
Instance Constructors From scala.collection.parallel.ParIterableLike.CopyToArray
--------------------------------------------------------------------------------


### `new CopyToArray(from: Int, len: Int, array: Array[U], pit: IterableSplitter[T])` ###

(defined at scala.collection.parallel.ParIterableLike.CopyToArray)


--------------------------------------------------------------------------------
    Value Members From scala.collection.parallel.ParIterableLike.CopyToArray
--------------------------------------------------------------------------------


### `def leaf(prev: Option[Unit]): Unit`                                     ###

Body of the task - non-divisible unit of work done by this task. Optionally is
provided with the result from the previous completed task or `None` if there was
no previous task (or the previous task is uncompleted or unknown).

* Definition Classes
  * CopyToArray → Task

(defined at scala.collection.parallel.ParIterableLike.CopyToArray)


### `def newSubtask(p: IterableSplitter[T]): Nothing`                        ###

* Attributes
  * protected[this]
* Definition Classes
  * CopyToArray → Accessor

(defined at scala.collection.parallel.ParIterableLike.CopyToArray)


### `val pit: IterableSplitter[T]`                                           ###

* Attributes
  * protected[this]
* Definition Classes
  * CopyToArray → Accessor

(defined at scala.collection.parallel.ParIterableLike.CopyToArray)


### `def requiresStrictSplitters: Boolean`                                   ###

* Definition Classes
  * CopyToArray → StrictSplitterCheckTask

(defined at scala.collection.parallel.ParIterableLike.CopyToArray)


### `var result: Unit`                                                       ###

A result that can be accessed once the task is completed.

* Definition Classes
  * CopyToArray → Task

(defined at scala.collection.parallel.ParIterableLike.CopyToArray)


### `def split: scala.Seq[Task[Unit, CopyToArray[U, This]]]`                 ###

Splits this task into a list of smaller tasks.

* Definition Classes
  * CopyToArray → Accessor → Task

(defined at scala.collection.parallel.ParIterableLike.CopyToArray)


--------------------------------------------------------------------------------
               Value Members From scala.collection.parallel.Task
--------------------------------------------------------------------------------


### `def forwardThrowable(): Unit`                                           ###

* Definition Classes
  * Task

(defined at scala.collection.parallel.Task)


### `def repr: CopyToArray[U, This]`                                         ###

* Definition Classes
  * Task

(defined at scala.collection.parallel.Task)


### `var throwable: Throwable`                                               ###

* Definition Classes
  * Task

(defined at scala.collection.parallel.Task)


--------------------------------------------------------------------------------
Value Members From Implicit scala.collection.parallel.CollectionsHaveToParArray
--------------------------------------------------------------------------------


### `def toParArray: ParArray[T]`                                            ###

* Implicit information
  * This member is added by an implicit conversion from CopyToArray [U, This] to
    CollectionsHaveToParArray [CopyToArray [U, This], T] performed by method
    CollectionsHaveToParArray in scala.collection.parallel. This conversion will
    take place only if an implicit value of type (CopyToArray [U, This]) ⇒
    GenTraversableOnce [T] is in scope.
* Definition Classes
  * CollectionsHaveToParArray
(added by implicit convertion: scala.collection.parallel.CollectionsHaveToParArray)
