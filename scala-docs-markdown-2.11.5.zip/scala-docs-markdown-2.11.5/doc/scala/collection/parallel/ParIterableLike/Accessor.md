
#              scala.collection.parallel.ParIterableLike#Accessor              #

```
trait Accessor[R, Tp] extends StrictSplitterCheckTask[R, Tp]
```

Standard accessor task that iterates over the elements of the collection.

* R
  * type of the result of this method ( `R` for result).
* Tp
  * the representation type of the task at hand.

* Attributes
  * protected
* Source
  * [ParIterableLike.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/parallel/ParIterableLike.scala#L1)


--------------------------------------------------------------------------------
                                  Type Members
--------------------------------------------------------------------------------


### `type Result = R`                                                        ###

* Definition Classes
  * Task


--------------------------------------------------------------------------------
 Abstract Value Members From scala.collection.parallel.ParIterableLike.Accessor
--------------------------------------------------------------------------------


### `abstract def newSubtask(p: IterableSplitter[T]): Accessor[R, Tp]`       ###

* Attributes
  * protected[this]

(defined at scala.collection.parallel.ParIterableLike.Accessor)


### `abstract val pit: IterableSplitter[T]`                                  ###

* Attributes
  * protected[this]

(defined at scala.collection.parallel.ParIterableLike.Accessor)


--------------------------------------------------------------------------------
 Concrete Value Members From scala.collection.parallel.ParIterableLike.Accessor
--------------------------------------------------------------------------------


### `def shouldSplitFurther: Boolean`                                        ###

Decides whether or not this task should be split further.

* Definition Classes
  * Accessor → Task

(defined at scala.collection.parallel.ParIterableLike.Accessor)


### `def split: scala.Seq[Task[R, Tp]]`                                      ###

Splits this task into a list of smaller tasks.

* Definition Classes
  * Accessor → Task

(defined at scala.collection.parallel.ParIterableLike.Accessor)


### `def toString(): String`                                                 ###

Creates a String representation of this object. The default representation is
platform dependent. On the java platform it is the concatenation of the class
name, "@", and the object's hashcode in hexadecimal.

* returns
  * a String representation of the object.

* Definition Classes
  * Accessor → AnyRef → Any

(defined at scala.collection.parallel.ParIterableLike.Accessor)


--------------------------------------------------------------------------------
Concrete Value Members From scala.collection.parallel.ParIterableLike.StrictSplitterCheckTask
--------------------------------------------------------------------------------


### `def requiresStrictSplitters: Boolean`                                   ###

* Definition Classes
  * StrictSplitterCheckTask

(defined at scala.collection.parallel.ParIterableLike.StrictSplitterCheckTask)


--------------------------------------------------------------------------------
           Abstract Value Members From scala.collection.parallel.Task
--------------------------------------------------------------------------------


### `abstract def leaf(result: Option[R]): Unit`                             ###

Body of the task - non-divisible unit of work done by this task. Optionally is
provided with the result from the previous completed task or `None` if there was
no previous task (or the previous task is uncompleted or unknown).

* Definition Classes
  * Task

(defined at scala.collection.parallel.Task)


### `abstract val result: R`                                                 ###

A result that can be accessed once the task is completed.

* Definition Classes
  * Task

(defined at scala.collection.parallel.Task)


--------------------------------------------------------------------------------
           Concrete Value Members From scala.collection.parallel.Task
--------------------------------------------------------------------------------


### `def forwardThrowable(): Unit`                                           ###

* Definition Classes
  * Task

(defined at scala.collection.parallel.Task)


### `def repr: Tp`                                                           ###

* Definition Classes
  * Task

(defined at scala.collection.parallel.Task)


### `var throwable: Throwable`                                               ###

* Definition Classes
  * Task

(defined at scala.collection.parallel.Task)


--------------------------------------------------------------------------------
Concrete Value Members From Implicit scala.collection.parallel.CollectionsHaveToParArray
--------------------------------------------------------------------------------


### `def toParArray: ParArray[T]`                                            ###

* Implicit information
  * This member is added by an implicit conversion from Accessor [R, Tp] to
    CollectionsHaveToParArray [Accessor [R, Tp], T] performed by method
    CollectionsHaveToParArray in scala.collection.parallel. This conversion will
    take place only if an implicit value of type (Accessor [R, Tp]) ⇒
    GenTraversableOnce [T] is in scope.
* Definition Classes
  * CollectionsHaveToParArray
(added by implicit convertion: scala.collection.parallel.CollectionsHaveToParArray)
