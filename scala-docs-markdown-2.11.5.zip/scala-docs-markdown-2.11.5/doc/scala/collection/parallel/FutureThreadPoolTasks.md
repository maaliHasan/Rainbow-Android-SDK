
#               scala.collection.parallel.FutureThreadPoolTasks               #

```
object FutureThreadPoolTasks
```

* Source
  * [Tasks.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/parallel/Tasks.scala#L1)


--------------------------------------------------------------------------------
       Value Members From scala.collection.parallel.FutureThreadPoolTasks
--------------------------------------------------------------------------------


### `val defaultThreadPool: ExecutorService`                                 ###

(defined at scala.collection.parallel.FutureThreadPoolTasks)


### `val numCores: Int`                                                      ###

(defined at scala.collection.parallel.FutureThreadPoolTasks)


### `val tcount: AtomicLong`                                                 ###
(defined at scala.collection.parallel.FutureThreadPoolTasks)
