
#       scala.collection.parallel.AdaptiveWorkStealingTasks#WrappedTask       #

```
trait WrappedTask[R, Tp] extends AdaptiveWorkStealingTasks.WrappedTask[R, Tp]
```

* Source
  * [Tasks.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/parallel/Tasks.scala#L1)


--------------------------------------------------------------------------------
Abstract Value Members From scala.collection.parallel.AdaptiveWorkStealingTasks.WrappedTask
--------------------------------------------------------------------------------


### `abstract def split: scala.Seq[WrappedTask[R, Tp]]`                      ###

* Definition Classes
  * WrappedTask → WrappedTask

(defined at scala.collection.parallel.AdaptiveWorkStealingTasks.WrappedTask)


--------------------------------------------------------------------------------
Concrete Value Members From scala.collection.parallel.AdaptiveWorkStealingTasks.WrappedTask
--------------------------------------------------------------------------------


### `def compute(): Unit`                                                    ###

Code that gets called after the task gets started - it may spawn other tasks
instead of calling `leaf` .

* Definition Classes
  * WrappedTask → WrappedTask

(defined at scala.collection.parallel.AdaptiveWorkStealingTasks.WrappedTask)


### `def internal(): Unit`                                                   ###

(defined at scala.collection.parallel.AdaptiveWorkStealingTasks.WrappedTask)


### `var next: WrappedTask[R, Tp]`                                           ###

(defined at scala.collection.parallel.AdaptiveWorkStealingTasks.WrappedTask)


### `def printChain(): Unit`                                                 ###

(defined at scala.collection.parallel.AdaptiveWorkStealingTasks.WrappedTask)


### `var shouldWaitFor: Boolean`                                             ###

(defined at scala.collection.parallel.AdaptiveWorkStealingTasks.WrappedTask)


### `def spawnSubtasks(): WrappedTask[R, Tp]`                                ###

(defined at scala.collection.parallel.AdaptiveWorkStealingTasks.WrappedTask)


--------------------------------------------------------------------------------
    Abstract Value Members From scala.collection.parallel.Tasks.WrappedTask
--------------------------------------------------------------------------------


### `abstract val body: Task[R, Tp]`                                         ###

the body of this task - what it executes, how it gets split and how results are
merged.

* Definition Classes
  * WrappedTask

(defined at scala.collection.parallel.Tasks.WrappedTask)


### `abstract def start(): Unit`                                             ###

Start task.

* Definition Classes
  * WrappedTask

(defined at scala.collection.parallel.Tasks.WrappedTask)


### `abstract def sync(): Unit`                                              ###

Wait for task to finish.

* Definition Classes
  * WrappedTask

(defined at scala.collection.parallel.Tasks.WrappedTask)


### `abstract def tryCancel(): Boolean`                                      ###

Try to cancel the task.

* returns
  * `true` if cancellation is successful.

* Definition Classes
  * WrappedTask

(defined at scala.collection.parallel.Tasks.WrappedTask)


--------------------------------------------------------------------------------
    Concrete Value Members From scala.collection.parallel.Tasks.WrappedTask
--------------------------------------------------------------------------------


### `def release(): Unit`                                                    ###

If the task has been cancelled successfully, those syncing on it may
automatically be notified, depending on the implementation. If they aren't, this
release method should be called after processing the cancelled task.

This method may be overridden.

* Definition Classes
  * WrappedTask

(defined at scala.collection.parallel.Tasks.WrappedTask)


--------------------------------------------------------------------------------
Concrete Value Members From Implicit scala.collection.parallel.CollectionsHaveToParArray
--------------------------------------------------------------------------------


### `def toParArray: ParArray[T]`                                            ###

* Implicit information
  * This member is added by an implicit conversion from WrappedTask [R, Tp] to
    CollectionsHaveToParArray [WrappedTask [R, Tp], T] performed by method
    CollectionsHaveToParArray in scala.collection.parallel. This conversion will
    take place only if an implicit value of type (WrappedTask [R, Tp]) ⇒
    GenTraversableOnce [T] is in scope.
* Definition Classes
  * CollectionsHaveToParArray
(added by implicit convertion: scala.collection.parallel.CollectionsHaveToParArray)
