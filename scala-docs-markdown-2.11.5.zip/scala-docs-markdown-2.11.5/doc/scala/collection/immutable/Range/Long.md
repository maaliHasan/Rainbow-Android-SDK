
#                    scala.collection.immutable.Range.Long                    #

```
object Long
```

* Source
  * [Range.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/immutable/Range.scala#L1)


--------------------------------------------------------------------------------
            Value Members From scala.collection.immutable.Range.Long
--------------------------------------------------------------------------------


### `def apply(start: Long, end: Long, step: Long): Exclusive[Long]`         ###

(defined at scala.collection.immutable.Range.Long)


### `def inclusive(start: Long, end: Long, step: Long): NumericRange.Inclusive[Long]` ###
(defined at scala.collection.immutable.Range.Long)
