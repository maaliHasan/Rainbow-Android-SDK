
#                     scala.collection.immutable.Range.Int                     #

```
object Int
```

* Source
  * [Range.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/immutable/Range.scala#L1)


--------------------------------------------------------------------------------
            Value Members From scala.collection.immutable.Range.Int
--------------------------------------------------------------------------------


### `def apply(start: Int, end: Int, step: Int): Exclusive[Int]`             ###

(defined at scala.collection.immutable.Range.Int)


### `def inclusive(start: Int, end: Int, step: Int): NumericRange.Inclusive[Int]` ###
(defined at scala.collection.immutable.Range.Int)
