
#              scala.collection.immutable.StreamIterator#LazyCell              #

```
class LazyCell extends AnyRef
```

* Source
  * [Stream.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/immutable/Stream.scala#L1)


--------------------------------------------------------------------------------
 Instance Constructors From scala.collection.immutable.StreamIterator.LazyCell
--------------------------------------------------------------------------------


### `new LazyCell(st: ⇒ Stream[A])`                                          ###

(defined at scala.collection.immutable.StreamIterator.LazyCell)


--------------------------------------------------------------------------------
     Value Members From scala.collection.immutable.StreamIterator.LazyCell
--------------------------------------------------------------------------------


### `lazy val v: Stream[A]`                                                  ###
(defined at scala.collection.immutable.StreamIterator.LazyCell)
