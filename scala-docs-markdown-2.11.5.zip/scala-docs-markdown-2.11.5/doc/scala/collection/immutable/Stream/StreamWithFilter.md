
#              scala.collection.immutable.Stream#StreamWithFilter              #

```
final class StreamWithFilter extends WithFilter
```

A lazier implementation of WithFilter than TraversableLike's.

* Source
  * [Stream.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/immutable/Stream.scala#L1)


--------------------------------------------------------------------------------
 Instance Constructors From scala.collection.immutable.Stream.StreamWithFilter
--------------------------------------------------------------------------------


### `new StreamWithFilter(p: (A) ⇒ Boolean)`                                 ###

(defined at scala.collection.immutable.Stream.StreamWithFilter)


--------------------------------------------------------------------------------
     Value Members From scala.collection.immutable.Stream.StreamWithFilter
--------------------------------------------------------------------------------


### `def flatMap[B, That](f: (A) ⇒ GenTraversableOnce[B])(implicit bf: CanBuildFrom[Stream[A], B, That]): That` ###

[use case]

Builds a new collection by applying a function to all elements of the outer
stream containing this `WithFilter` instance that satisfy predicate `p` and
concatenating the results.

The type of the resulting collection will be guided by the static type of the
outer stream.

* B
  * the element type of the returned collection.
* f
  * the function to apply to each element.
* returns
  * a new stream resulting from applying the given collection-valued function
     `f` to each element of the outer stream that satisfies predicate `p` and
    concatenating the results.

* Definition Classes
  * StreamWithFilter → WithFilter → FilterMonadic

(defined at scala.collection.immutable.Stream.StreamWithFilter)


### `def foreach[B](f: (A) ⇒ B): Unit`                                       ###

[use case]

Applies a function `f` to all elements of the outer stream containing this
 `WithFilter` instance that satisfy predicate `p` .

* f
  * the function that is applied for its side-effect to every element. The
    result of function `f` is discarded.

* Definition Classes
  * StreamWithFilter → WithFilter → FilterMonadic

(defined at scala.collection.immutable.Stream.StreamWithFilter)


### `def map[B, That](f: (A) ⇒ B)(implicit bf: CanBuildFrom[Stream[A], B, That]): That` ###

[use case]

Builds a new collection by applying a function to all elements of the outer
stream containing this `WithFilter` instance that satisfy predicate `p` .

* B
  * the element type of the returned collection.
* f
  * the function to apply to each element.
* returns
  * a new stream resulting from applying the given function `f` to each element
    of the outer stream that satisfies predicate `p` and collecting the results.

* Definition Classes
  * StreamWithFilter → WithFilter → FilterMonadic

(defined at scala.collection.immutable.Stream.StreamWithFilter)


### `def withFilter(q: (A) ⇒ Boolean): StreamWithFilter`                     ###

Further refines the filter for this stream.

* q
  * the predicate used to test elements.
* returns
  * an object of class `WithFilter` , which supports `map` , `flatMap` ,
     `foreach` , and `withFilter` operations. All these operations apply to
    those elements of this stream which satisfy the predicate `q` in addition to
    the predicate `p` .

* Definition Classes
  * StreamWithFilter → WithFilter → FilterMonadic

(defined at scala.collection.immutable.Stream.StreamWithFilter)


--------------------------------------------------------------------------------
Value Members From Implicit scala.collection.parallel.CollectionsHaveToParArray
--------------------------------------------------------------------------------


### `def toParArray: ParArray[T]`                                            ###

* Implicit information
  * This member is added by an implicit conversion from StreamWithFilter to
    CollectionsHaveToParArray [StreamWithFilter, T] performed by method
    CollectionsHaveToParArray in scala.collection.parallel. This conversion will
    take place only if an implicit value of type (StreamWithFilter) ⇒
    GenTraversableOnce [T] is in scope.
* Definition Classes
  * CollectionsHaveToParArray
(added by implicit convertion: scala.collection.parallel.CollectionsHaveToParArray)
