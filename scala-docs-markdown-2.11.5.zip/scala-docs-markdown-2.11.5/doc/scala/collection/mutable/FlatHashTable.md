
#                    scala.collection.mutable.FlatHashTable                    #

```
trait FlatHashTable[A] extends HashUtils[A]
```

An implementation class backing a `HashSet` .

This trait is used internally. It can be mixed in with various collections
relying on hash table as an implementation.

* Source
  * [FlatHashTable.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/mutable/FlatHashTable.scala#L1)


--------------------------------------------------------------------------------
           Value Members From scala.collection.mutable.FlatHashTable
--------------------------------------------------------------------------------


### `def addElem(elem: A): Boolean`                                          ###

Add elem if not yet in table.

* returns
  * Returns `true` if a new elem was added, `false` otherwise.

* Attributes
  * protected

(defined at scala.collection.mutable.FlatHashTable)


### `def addEntry(newEntry: AnyRef): Boolean`                                ###

Add an entry (an elem converted to an entry via elemToEntry) if not yet in
table.

* returns
  * Returns `true` if a new elem was added, `false` otherwise.

* Attributes
  * protected

(defined at scala.collection.mutable.FlatHashTable)


### `def alwaysInitSizeMap: Boolean`                                         ###

* Attributes
  * protected

(defined at scala.collection.mutable.FlatHashTable)


### `def calcSizeMapSize(tableLength: Int): Int`                             ###

* Attributes
  * protected
* Annotations
  * @deprecatedOverriding (..., "2.11.0")

(defined at scala.collection.mutable.FlatHashTable)


### `def capacity(expectedSize: Int): Int`                                   ###

* Attributes
  * protected

(defined at scala.collection.mutable.FlatHashTable)


### `def clearTable(): Unit`                                                 ###

* Attributes
  * protected

(defined at scala.collection.mutable.FlatHashTable)


### `def containsElem(elem: A): Boolean`                                     ###

Checks whether an element is contained in the hash table.

* Attributes
  * protected
* Annotations
  * @deprecatedOverriding (..., "2.11.0")

(defined at scala.collection.mutable.FlatHashTable)


### `def findEntry(elem: A): Option[A]`                                      ###

Finds an entry in the hash table if such an element exists.

* Attributes
  * protected
* Annotations
  * @deprecatedOverriding (..., "2.11.0")

(defined at scala.collection.mutable.FlatHashTable)


### `final def index(hcode: Int): Int`                                       ###

* Attributes
  * protected

(defined at scala.collection.mutable.FlatHashTable)


### `def initWithContents(c: Contents[A]): Unit`                             ###

* Attributes
  * protected

(defined at scala.collection.mutable.FlatHashTable)


### `def initialSize: Int`                                                   ###

The initial size of the hash table.

(defined at scala.collection.mutable.FlatHashTable)


### `def isSizeMapDefined: Boolean`                                          ###

* Attributes
  * protected

(defined at scala.collection.mutable.FlatHashTable)


### `def iterator: Iterator[A]`                                              ###

* Attributes
  * protected

(defined at scala.collection.mutable.FlatHashTable)


### `def nnSizeMapAdd(h: Int): Unit`                                         ###

* Attributes
  * protected
* Annotations
  * @deprecatedOverriding (..., "2.11.0")

(defined at scala.collection.mutable.FlatHashTable)


### `def nnSizeMapRemove(h: Int): Unit`                                      ###

* Attributes
  * protected
* Annotations
  * @deprecatedOverriding (..., "2.11.0")

(defined at scala.collection.mutable.FlatHashTable)


### `def nnSizeMapReset(tableLength: Int): Unit`                             ###

* Attributes
  * protected
* Annotations
  * @deprecatedOverriding (..., "2.11.0")

(defined at scala.collection.mutable.FlatHashTable)


### `def randomSeed: Int`                                                    ###

* Attributes
  * protected

(defined at scala.collection.mutable.FlatHashTable)


### `def removeElem(elem: A): Boolean`                                       ###

Removes an elem from the hash table returning true if the element was found (and
thus removed) or false if it didn't exist.

* Attributes
  * protected

(defined at scala.collection.mutable.FlatHashTable)


### `var seedvalue: Int`                                                     ###

* Attributes
  * protected

(defined at scala.collection.mutable.FlatHashTable)


### `def sizeMapDisable(): Unit`                                             ###

* Attributes
  * protected

(defined at scala.collection.mutable.FlatHashTable)


### `def sizeMapInit(tableLength: Int): Unit`                                ###

* Attributes
  * protected
* Annotations
  * @deprecatedOverriding (..., "2.11.0")

(defined at scala.collection.mutable.FlatHashTable)


### `def sizeMapInitAndRebuild(): Unit`                                      ###

* Attributes
  * protected
* Annotations
  * @deprecatedOverriding (..., "2.11.0")

(defined at scala.collection.mutable.FlatHashTable)


### `var sizemap: Array[Int]`                                                ###

The array keeping track of number of elements in 32 element blocks.

* Attributes
  * protected

(defined at scala.collection.mutable.FlatHashTable)


### `var table: Array[AnyRef]`                                               ###

The actual hash table.

* Attributes
  * protected

(defined at scala.collection.mutable.FlatHashTable)


### `var tableSize: Int`                                                     ###

The number of mappings contained in this hash table.

* Attributes
  * protected

(defined at scala.collection.mutable.FlatHashTable)


### `def tableSizeSeed: Int`                                                 ###

* Attributes
  * protected

(defined at scala.collection.mutable.FlatHashTable)


### `var threshold: Int`                                                     ###

The next size value at which to resize (capacity * load factor).

* Attributes
  * protected

(defined at scala.collection.mutable.FlatHashTable)


--------------------------------------------------------------------------------
      Value Members From scala.collection.mutable.FlatHashTable.HashUtils
--------------------------------------------------------------------------------


### `final def elemToEntry(elem: A): AnyRef`                                 ###

Elems have type A, but we store AnyRef in the table. Plus we need to deal with
null elems, which need to be stored as NullSentinel

* Attributes
  * protected
* Definition Classes
  * HashUtils

(defined at scala.collection.mutable.FlatHashTable.HashUtils)


### `final def entryToElem(entry: AnyRef): A`                                ###

Does the inverse translation of elemToEntry

* Attributes
  * protected
* Definition Classes
  * HashUtils

(defined at scala.collection.mutable.FlatHashTable.HashUtils)


### `final def improve(hcode: Int, seed: Int): Int`                          ###

* Attributes
  * protected
* Definition Classes
  * HashUtils

(defined at scala.collection.mutable.FlatHashTable.HashUtils)


### `final def sizeMapBucketBitSize: Int`                                    ###

* Attributes
  * protected
* Definition Classes
  * HashUtils

(defined at scala.collection.mutable.FlatHashTable.HashUtils)


### `final def sizeMapBucketSize: Int`                                       ###

* Attributes
  * protected
* Definition Classes
  * HashUtils
(defined at scala.collection.mutable.FlatHashTable.HashUtils)
