
#                      scala.collection.mutable.HashEntry                      #

```
trait HashEntry[A, E] extends AnyRef
```

Class used internally.

* Source
  * [HashEntry.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/mutable/HashEntry.scala#L1)
* Since
  * 2.8


--------------------------------------------------------------------------------
         Abstract Value Members From scala.collection.mutable.HashEntry
--------------------------------------------------------------------------------


### `abstract val key: A`                                                    ###

(defined at scala.collection.mutable.HashEntry)


--------------------------------------------------------------------------------
         Concrete Value Members From scala.collection.mutable.HashEntry
--------------------------------------------------------------------------------


### `var next: E`                                                            ###
(defined at scala.collection.mutable.HashEntry)
