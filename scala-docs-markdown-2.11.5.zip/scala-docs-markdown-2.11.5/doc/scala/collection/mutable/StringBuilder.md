
#                    scala.collection.mutable.StringBuilder                    #

```
object StringBuilder extends Serializable
```

* Source
  * [StringBuilder.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/mutable/StringBuilder.scala#L1)


--------------------------------------------------------------------------------
           Value Members From scala.collection.mutable.StringBuilder
--------------------------------------------------------------------------------


### `def newBuilder: StringBuilder`                                          ###
(defined at scala.collection.mutable.StringBuilder)
