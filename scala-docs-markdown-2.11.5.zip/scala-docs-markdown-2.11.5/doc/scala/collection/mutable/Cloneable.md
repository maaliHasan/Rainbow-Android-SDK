
#                      scala.collection.mutable.Cloneable                      #

```
trait Cloneable[+A <: AnyRef] extends scala.Cloneable
```

A trait for cloneable collections.

* A
  * Type of the elements contained in the collection, covariant and with
    reference types as upperbound.

* Source
  * [Cloneable.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/mutable/Cloneable.scala#L1)
* Since
  * 2.8


--------------------------------------------------------------------------------
             Value Members From scala.collection.mutable.Cloneable
--------------------------------------------------------------------------------


### `def clone(): A`                                                         ###

Create a copy of the receiver object.

The default implementation of the `clone` method is platform dependent.

* returns
  * a copy of the receiver object.

* Definition Classes
  * Cloneable → AnyRef
* Note
  * not specified by SLS as a member of AnyRef
(defined at scala.collection.mutable.Cloneable)
