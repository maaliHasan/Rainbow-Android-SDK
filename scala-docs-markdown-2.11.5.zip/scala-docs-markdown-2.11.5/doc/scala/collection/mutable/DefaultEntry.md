
#                    scala.collection.mutable.DefaultEntry                    #

```
final class DefaultEntry[A, B] extends HashEntry[A, DefaultEntry[A, B]] with Serializable
```

Class used internally for default map model.

* Source
  * [DefaultEntry.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/mutable/DefaultEntry.scala#L1)
* Since
  * 2.3


--------------------------------------------------------------------------------
        Instance Constructors From scala.collection.mutable.DefaultEntry
--------------------------------------------------------------------------------


### `new DefaultEntry(key: A, value: B)`                                     ###

(defined at scala.collection.mutable.DefaultEntry)


--------------------------------------------------------------------------------
            Value Members From scala.collection.mutable.DefaultEntry
--------------------------------------------------------------------------------


### `def chainString: String`                                                ###

(defined at scala.collection.mutable.DefaultEntry)


### `val key: A`                                                             ###

* Definition Classes
  * DefaultEntry → HashEntry

(defined at scala.collection.mutable.DefaultEntry)


### `def toString(): String`                                                 ###

Creates a String representation of this object. The default representation is
platform dependent. On the java platform it is the concatenation of the class
name, "@", and the object's hashcode in hexadecimal.

* returns
  * a String representation of the object.

* Definition Classes
  * DefaultEntry → AnyRef → Any

(defined at scala.collection.mutable.DefaultEntry)


### `var value: B`                                                           ###

(defined at scala.collection.mutable.DefaultEntry)


--------------------------------------------------------------------------------
             Value Members From scala.collection.mutable.HashEntry
--------------------------------------------------------------------------------


### `var next: DefaultEntry[A, B]`                                           ###

* Definition Classes
  * HashEntry
(defined at scala.collection.mutable.HashEntry)
