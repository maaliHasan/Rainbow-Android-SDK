
#                    scala.collection.generic.SliceInterval                    #

```
object SliceInterval
```

* Source
  * [SliceInterval.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/generic/SliceInterval.scala#L1)


--------------------------------------------------------------------------------
           Value Members From scala.collection.generic.SliceInterval
--------------------------------------------------------------------------------


### `def apply(from: Int, until: Int): SliceInterval`                        ###
(defined at scala.collection.generic.SliceInterval)
