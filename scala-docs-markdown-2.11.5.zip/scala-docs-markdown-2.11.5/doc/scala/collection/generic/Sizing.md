
#                       scala.collection.generic.Sizing                       #

```
trait Sizing extends AnyRef
```

A trait for objects which have a size.

* Source
  * [Sizing.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/generic/Sizing.scala#L1)


--------------------------------------------------------------------------------
          Abstract Value Members From scala.collection.generic.Sizing
--------------------------------------------------------------------------------


### `abstract def size: Int`                                                 ###
(defined at scala.collection.generic.Sizing)
