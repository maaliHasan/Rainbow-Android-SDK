
#                    scala.collection.generic.FilterMonadic                    #

```
trait FilterMonadic[+A, +Repr] extends Any
```

A template trait that contains just the `map` , `flatMap` , `foreach` and
 `withFilter` methods of trait `TraversableLike` .

* Source
  * [FilterMonadic.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/generic/FilterMonadic.scala#L1)


--------------------------------------------------------------------------------
                    Concrete Value Members From scala.Any###
--------------------------------------------------------------------------------


### `final def ##(): Int`                                                    ###

Equivalent to `x.hashCode` except for boxed numeric types and `null` . For
numerics, it returns a hash value which is consistent with value equality: if
two value type instances compare as true, then ## will produce the same hash
value for each of them. For `null` returns a hashcode where `null.hashCode`
throws a `NullPointerException` .

* returns
  * a hash value consistent with ==

* Definition Classes
  * Any

(defined at scala.Any###)


--------------------------------------------------------------------------------
       Abstract Value Members From scala.collection.generic.FilterMonadic
--------------------------------------------------------------------------------


### `abstract def flatMap[B, That](f: (A) ⇒ GenTraversableOnce[B])(implicit bf: CanBuildFrom[Repr, B, That]): That` ###

(defined at scala.collection.generic.FilterMonadic)


### `abstract def foreach[U](f: (A) ⇒ U): Unit`                              ###

(defined at scala.collection.generic.FilterMonadic)


### `abstract def map[B, That](f: (A) ⇒ B)(implicit bf: CanBuildFrom[Repr, B, That]): That` ###

(defined at scala.collection.generic.FilterMonadic)


### `abstract def withFilter(p: (A) ⇒ Boolean): FilterMonadic[A, Repr]`      ###
(defined at scala.collection.generic.FilterMonadic)
