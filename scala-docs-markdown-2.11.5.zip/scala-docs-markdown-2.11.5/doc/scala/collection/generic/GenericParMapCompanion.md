
#               scala.collection.generic.GenericParMapCompanion               #

```
trait GenericParMapCompanion[+CC[P, Q] <: ParMap[P, Q]] extends AnyRef
```

* Source
  * [GenericParCompanion.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/generic/GenericParCompanion.scala#L1)


--------------------------------------------------------------------------------
  Abstract Value Members From scala.collection.generic.GenericParMapCompanion
--------------------------------------------------------------------------------


### `abstract def newCombiner[P, Q]: Combiner[(P, Q), CC[P, Q]]`             ###
(defined at scala.collection.generic.GenericParMapCompanion)
