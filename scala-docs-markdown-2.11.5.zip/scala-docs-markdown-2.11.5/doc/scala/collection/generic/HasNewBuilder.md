
#                    scala.collection.generic.HasNewBuilder                    #

```
trait HasNewBuilder[+A, +Repr] extends Any
```

* Source
  * [HasNewBuilder.scala](https://github.com/scala/scala/tree/v2.11.5/src/library/scala/collection/generic/HasNewBuilder.scala#L1)


--------------------------------------------------------------------------------
                    Concrete Value Members From scala.Any###
--------------------------------------------------------------------------------


### `final def ##(): Int`                                                    ###

Equivalent to `x.hashCode` except for boxed numeric types and `null` . For
numerics, it returns a hash value which is consistent with value equality: if
two value type instances compare as true, then ## will produce the same hash
value for each of them. For `null` returns a hashcode where `null.hashCode`
throws a `NullPointerException` .

* returns
  * a hash value consistent with ==

* Definition Classes
  * Any

(defined at scala.Any###)


--------------------------------------------------------------------------------
       Abstract Value Members From scala.collection.generic.HasNewBuilder
--------------------------------------------------------------------------------


### `abstract def newBuilder: Builder[A, Repr]`                              ###

The builder that builds instances of Repr

* Attributes
  * protected[this]
(defined at scala.collection.generic.HasNewBuilder)
