
#                                 scala.AnyRef                                 #

```
class AnyRef extends Any
```

Class `AnyRef` is the root class of all _reference types_ . All types except the
value types descend from this class.

